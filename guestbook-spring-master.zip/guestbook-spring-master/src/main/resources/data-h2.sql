INSERT INTO entries (user, comment) VALUES ('Catrin Morgan', 'Nice use of contrast in this colour palette.');
INSERT INTO entries (user, comment) VALUES ('Cletus Spalding', 'It''s splendid not just sleek!');
INSERT INTO entries (user, comment) VALUES ('Grigor Martel', 'This is alluring work! ');
INSERT INTO entries (user, comment) VALUES ('Finnegan Draper', 'Super thought out! Leading the way, mate.');
INSERT INTO entries (user, comment) VALUES ('Zac Quincy', 'My 49 year old daughter rates this shot very splendid :)');
INSERT INTO entries (user, comment) VALUES ('Grigor Martel', 'Such shot, many button, so simple.');
INSERT INTO entries (user, comment) VALUES ('Terrence Sutherland', 'Looks revolutionary and admirable, friend.');
INSERT INTO entries (user, comment) VALUES ('Terrence Sutherland', 'I want to learn this kind of shot! Teach me.');
INSERT INTO entries (user, comment) VALUES ('Zac Quincy', 'Incredible work you have here.');
INSERT INTO entries (user, comment) VALUES ('Grigor Martel', 'Engaging. It keeps your mind occupied while you wait.');
INSERT INTO entries (user, comment) VALUES ('Katharine McKenzie', 'White. This is new school.');
INSERT INTO entries (user, comment) VALUES ('Zac Quincy', 'I approve your shot.');

